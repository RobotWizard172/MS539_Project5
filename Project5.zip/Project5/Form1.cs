﻿/*
 * Jeff Koss
 * Date: 04/15/2023
 * Class: MS539 - Programming Concepts
 * Professor: Jill Coddington
 * Assignment: Project 5 Inheritance and Classes
 * ETA: 2 Hours
 */


//This project went very well I had it done in 2 hours.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectInherit
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        class Orc //Base Class
        {
           public string greeting;
           public string weapon;

           private int health = 50;
           private int damage = 10;

            public string Greet()
            {
                return greeting;
            }

            public Orc() // Constructor for base class
            {
                weapon = "Club";
                greeting = "You see a stalwart Orc standing before you, it is weilding a " + weapon;
            }


        }

        class OrcWizard : Orc //Inherited class from Orc
        {
            public OrcWizard() //Constructor for Orc Wizard
            {
                weapon = "Staff";
                greeting = "You see a Gnarly Orc Wizard standing before you, it is weilding a " + weapon;
            }
        }

        class OrcHero : Orc //Inherited class from Orc
        {
            public OrcHero() //Constructor for Orc Hero
            {
                weapon = "Sword and Shield";
                greeting = "You see a Huge Orc Hero standing before you, it is weilding a " + weapon;
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Orc myorc = new Orc();
            textBox1.Text = myorc.Greet();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OrcWizard myorcwizard = new OrcWizard();
            textBox1.Text = myorcwizard.Greet();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OrcHero myorchero = new OrcHero();
            textBox1.Text = myorchero.Greet();
        }  
    }

    
    

}
